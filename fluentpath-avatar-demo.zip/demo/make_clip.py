"""Make a Malayalam speech clip with Sarvam Bulbul v3 for the avatar demo.

Usage (on your own machine, where api.sarvam.ai is reachable):
    pip install sarvamai
    set SARVAM_API_KEY=your-key        (Windows)   |   export SARVAM_API_KEY=your-key
    python make_clip.py "നമസ്കാരം, എന്താണ് പ്രശ്നം?"

Writes sample_ml.wav next to this file.
Bulbul v3 is used because Malayalam is not offered on Bulbul v4 Flash.
"""
import os
import sys

from sarvamai import SarvamAI
from sarvamai.play import save

key = os.environ.get("SARVAM_API_KEY")
if not key:
    sys.exit("Set the SARVAM_API_KEY environment variable first.")

text = " ".join(sys.argv[1:]) or "നമസ്കാരം. എനിക്ക് നിങ്ങളെ സഹായിക്കാൻ കഴിയും. എന്താണ് പ്രശ്നം?"
client = SarvamAI(api_subscription_key=key)
resp = client.text_to_speech.convert(
    text=text,
    language_code="ml-IN",
    model="bulbul:v3",
    speaker="shubh",
    pace=1.0,
    speech_sample_rate=24000,
)
out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sample_ml.wav")
save(resp, out)
print("wrote", out)
