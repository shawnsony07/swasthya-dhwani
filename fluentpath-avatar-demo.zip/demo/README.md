# FluentPath avatar demo (free tier)

3D avatar that lip-syncs to any audio, including Sarvam Bulbul v3 Malayalam.

Parts and licences
- TalkingHead (MIT): 3D avatar, three.js, in `modules/`
- HeadAudio (MIT): audio-driven lip-sync, in `dist/`. Its model `model-en-mixed` was trained on English; Malayalam accuracy is untested.
- three.js (MIT): in `vendor/three/`
- Avatar `avatars/mpfb.glb`: made with Blender and MPFB, CC0 (per the TalkingHead README). Do not use `brunette.glb`: it is CC BY-NC, non-commercial.

Run
1. `pip install sarvamai`, set `SARVAM_API_KEY`, then `python make_clip.py` (makes `sample_ml.wav`)
2. `python -m http.server 8000` in this folder
3. Open http://localhost:8000 in Chrome, click "Play sample_ml.wav" (a click is needed to start audio)

Later wiring into the project
- Dashboard (Next.js): copy this folder's `modules`, `dist`, `vendor` and `avatars` into `public/`, load the page in an iframe or port `index.html` to a component.
- Live audio: feed Sarvam streaming audio (WebSocket, up to 24 kHz) into `head.audioSpeechGainNode` instead of a file.
- Keep the Sarvam key on the server; never put it in the browser.
